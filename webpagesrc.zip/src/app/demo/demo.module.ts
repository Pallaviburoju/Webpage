import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DemocComponent } from './democ/democ.component';
import { Democ2Component } from './democ2/democ2.component';
import { Routes, RouterModule } from '@angular/router';
import {MatTabsModule} from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';

const route: Routes=[
  { path:'democ1', component: DemocComponent },
  { path:'democ2', component: Democ2Component },
  { path: '**', redirectTo: 'democ2' }
]

@NgModule({
  declarations: [DemocComponent, Democ2Component],
  imports: [
    CommonModule,
    MatTabsModule,
    MatButtonModule,
    RouterModule.forChild(route)
  ]
})
export class DemoModule { }

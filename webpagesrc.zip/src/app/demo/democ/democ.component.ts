import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-democ',
  templateUrl: './democ.component.html',
  styleUrls: ['./democ.component.css']
})
export class DemocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

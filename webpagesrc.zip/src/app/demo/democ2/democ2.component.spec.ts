import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Democ2Component } from './democ2.component';

describe('Democ2Component', () => {
  let component: Democ2Component;
  let fixture: ComponentFixture<Democ2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Democ2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Democ2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

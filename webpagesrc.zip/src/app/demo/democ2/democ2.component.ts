import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-democ2',
  templateUrl: './democ2.component.html',
  styleUrls: ['./democ2.component.css']
})
export class Democ2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

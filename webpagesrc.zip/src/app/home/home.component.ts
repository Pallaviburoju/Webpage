import { Component, OnInit, HostListener } from '@angular/core';
import { ScrollDispatcher } from '@angular/cdk/scrolling';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public scroll: ScrollDispatcher) { }
  
   data = [
    {name:"Pallavi", hotel:"Dolphin"},
    {name:"Stefan", hotel:"Dolphin"},
    {name:"Damon", hotel:"Dolphin"},
    {name:"Elena", hotel:"Dolphin"},
    {name:"Bonnie", hotel:"Dolphin"},
    {name:"Pallavi2", hotel:"Holiday"},
    {name:"Stefan2", hotel:"Holiday"},
    {name:"Damon2", hotel:"Holiday"},
    {name:"Elena2", hotel:"Holiday"},
    {name:"Bonnie2", hotel:"Holiday"},
    {name: "Caroline2", hotel:"Holiday"},
    {name:"Pallavi3", hotel:"Dream"},
    {name:"Stefan3", hotel:"Dream"},
    {name:"Damon3", hotel:"Dream"},
    {name:"Elena3", hotel:"Dream"},
    {name:"Bonnie3", hotel:"Dream"},
    {name: "Caroline3", hotel:"Dream"}
  ]
  ngOnInit() {
  }

  resortName: string;
  
//   @HostListener('window:scroll', ['$event']) 
//   scrollevent(event){
//   this.resortName = "dolphin";
//   console.log(this.resortName);
// }
@HostListener('window:scroll', ['$event']) 
    scrollHandler(event) {
      this.resortName = "dolphin";
      console.log(this.resortName);
}
     
}
